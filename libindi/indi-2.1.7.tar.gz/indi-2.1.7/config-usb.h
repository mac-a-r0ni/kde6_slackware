/* Define when libusb-1.0 has libusb_error_name() */
#define USB1_HAS_LIBUSB_ERROR_NAME
