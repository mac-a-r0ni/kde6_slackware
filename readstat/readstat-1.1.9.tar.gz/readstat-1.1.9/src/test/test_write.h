
readstat_error_t write_file_to_buffer(rt_test_file_t *file, rt_buffer_t *buffer, long format);
