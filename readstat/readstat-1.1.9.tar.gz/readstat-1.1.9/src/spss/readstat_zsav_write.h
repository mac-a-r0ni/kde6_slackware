
readstat_error_t zsav_write_compressed_row(void *writer_ctx, void *row, size_t len);
readstat_error_t zsav_end_data(void *writer_ctx);
