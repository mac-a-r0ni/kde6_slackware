
readstat_error_t xport_parse_format(const char *data, size_t len, xport_format_t *fmt,
        readstat_error_handler error_handler, void *user_ctx);

