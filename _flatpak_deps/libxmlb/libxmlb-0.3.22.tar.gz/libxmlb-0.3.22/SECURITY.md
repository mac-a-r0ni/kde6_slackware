# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.3.x   | :white_check_mark: |
| 0.2.x   | :x:                |
| 0.1.x   | :x:                |

## Reporting a Vulnerability

We have enabled private reporting in GitHub, so please [follow these steps](https://github.com/hughsie/libxmlb/security) to report vulnerabilities.
