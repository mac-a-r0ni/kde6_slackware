#!/bin/sh
pip3 install --user git+http://github.com/return42/linuxdoc.git
