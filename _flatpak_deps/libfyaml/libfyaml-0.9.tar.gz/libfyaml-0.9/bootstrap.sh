#!/bin/bash
# potato autoconf
touch build-aux/tap-driver.sh
autoreconf -fvi
