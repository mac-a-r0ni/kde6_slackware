.. libfyaml documentation master file, created by
   sphinx-quickstart on Sat May 25 20:55:33 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to libfyaml's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   man/fy-tool
   libfyaml


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
