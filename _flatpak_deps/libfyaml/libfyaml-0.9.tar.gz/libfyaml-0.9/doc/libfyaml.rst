Public API
==========

  .. kernel-doc:: include/libfyaml.h
     :internal:
