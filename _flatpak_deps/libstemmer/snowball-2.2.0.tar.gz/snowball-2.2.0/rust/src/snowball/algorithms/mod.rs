// Have a look at build.rs
include!(concat!(env!("OUT_DIR"), "/lang_include.rs"));
