<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="fr_FR">
<context>
    <name>QObject</name>
    <message>
        <location filename="kdeapp.cpp" line="4"/>
        <source>Hello World</source>
        <translation type="unfinished">Bonjour le monde</translation>
    </message>
</context>
</TS>
