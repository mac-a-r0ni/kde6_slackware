Planned, but not yet done:

* `as_screenshot_add_image(ss,im)` -> `as_screenshot_add_image(ss,locale,im)`
* `as_screenshot_get_images(ss)`   -> `as_screenshot_get_images(ss,locale)`
