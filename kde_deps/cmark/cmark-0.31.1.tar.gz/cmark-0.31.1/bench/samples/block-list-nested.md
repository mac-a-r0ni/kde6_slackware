
 - this
   - is
     - a
       - deeply
         - nested
           - bullet
             - list
   

 1. this
    2. is
       3. a
          4. deeply
             5. nested
                6. unordered
                   7. list


 - 1
  - 2
   - 3
    - 4
     - 5
      - 6
       - 7
      - 6
     - 5
    - 4
   - 3
  - 2
 - 1


 - - - - - - - - - deeply-nested one-element item

