*this *is *a *bunch* of* nested* emphases* 

__this __is __a __bunch__ of__ nested__ emphases__ 

***this ***is ***a ***bunch*** of*** nested*** emphases*** 
