> the simple example of a blockquote 
> the simple example of a blockquote
> the simple example of a blockquote
> the simple example of a blockquote
... continuation
... continuation
... continuation
... continuation

empty blockquote:

>
>
>
>

