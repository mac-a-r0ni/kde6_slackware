ddcutil
=======

The [ddcutil website](http://www.ddcutil.com) is the primary location of information for ddcutil users.

Recent announcements can be found on the [home page](http://www.ddcutil.com). 

Earlier announcements are located at [prior announcements](http://www.ddcutil.prior_announcements). 

Detailed information about user-visible changes for each release are located at [release notes](http://www.ddcutil.com/release_notes).
