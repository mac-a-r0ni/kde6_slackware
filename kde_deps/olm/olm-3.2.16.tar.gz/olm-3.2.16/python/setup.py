# -*- coding: utf-8 -*-
from setuptools import setup

setup(
    cffi_modules=["olm_build.py:ffibuilder"]
)
