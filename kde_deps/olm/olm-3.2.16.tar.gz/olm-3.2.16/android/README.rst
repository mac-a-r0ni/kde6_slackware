OlmLibSdk
=========

OlmLibSdk exposes an android wrapper to libolm.

Installation
------------

Android Olm library is released on MavenCentral.

Add this dependency to your project:

```groovy
implementation "org.matrix.android:olm:3.2.8"
```

Latest version: ![Latest version](https://img.shields.io/maven-central/v/org.matrix.android/olm)

Development
-----------
import the project from the ``android/`` path.

The project contains some JNI files and some Java wrapper files.

The project contains some tests under AndroidTests package.
