// SPDX-FileCopyrightText: 2021 Daniel Vrátil <dvratil@kde.org>
//
// SPDX-License-Identifier: MIT

#include "qcoroabstractsocket.h"
#include "qcorolocalsocket.h"
#include "qcoronetworkreply.h"
#include "qcorotcpserver.h"
