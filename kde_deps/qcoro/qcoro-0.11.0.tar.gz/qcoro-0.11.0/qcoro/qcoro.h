// SPDX-FileCopyrightText: 2021 Daniel Vrátil <dvratil@kde.org>
//
// SPDX-License-Identifier: MIT

#pragma once

#include "task.h"
#include "qcorocore.h"
#include "qcorodbus.h"
#include "qcoronetwork.h"
