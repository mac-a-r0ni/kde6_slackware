---
name: 'README: DO NOT IGNORE OR DELETE THE ISSUE TEMPLATE'
about: 'Chose and fill out one of the following templates!'
title: ''
labels: priority:ignored-issue-template
assignees: ''

---

We ask you to not ignore the issue template. Fill it out as good and correct as
possible. Issues that don't adhere to our request will be closed for ignoring
the issue template. This is because analyzing a bug without a log file is harder
than necessary. Low quality bug reports are noise.

Please go back and chose the proper issue template. Opening issues with this
template will be closed immediately.
