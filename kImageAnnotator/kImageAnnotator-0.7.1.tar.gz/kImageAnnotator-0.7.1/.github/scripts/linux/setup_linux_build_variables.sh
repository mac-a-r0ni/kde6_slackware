#!/bin/bash

echo "MAKE_BINARY=make" >> $GITHUB_ENV
echo "CMAKE_GENERATOR=Unix Makefiles" >> $GITHUB_ENV
