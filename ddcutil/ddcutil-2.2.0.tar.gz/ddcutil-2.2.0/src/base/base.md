/** \dir
Base services and definitions for the **ddcutil** application. 

Subdirectory base depends only on:
- File src/public/ddcutil_types.h, for publicly visible type definitions
- Subdirectory src/util, for application agnostic services

*/
