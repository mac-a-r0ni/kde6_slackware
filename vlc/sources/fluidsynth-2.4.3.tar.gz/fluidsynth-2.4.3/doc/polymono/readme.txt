/fluidSynth/doc/polymono directory contains:

1) FluidPolyMono-0004.pdf, the documentation of poly/mono functionalities.
2) tutorials examples files:
2.1) tutorials chapter 2.1
     poly_mono_0.txt
     poly_mono_1.txt
     poly_mono_2.txt
     poly_mono_3.txt
     poly_mono_4.txt
     poly_mono_5.txt

2.2) tutorials chapter 3.1
     leg_00.txt    
     leg_01.txt
     leg_por_00.txt    
     leg_por_01.txt

These tutorials files are usable directly on the FluidSynth console application.
See the pdf file (chapters 2.1 and 3.1).

jean-jacques ceresa
