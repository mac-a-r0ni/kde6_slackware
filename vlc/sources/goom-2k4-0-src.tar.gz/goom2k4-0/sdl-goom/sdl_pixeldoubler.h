#include <SDL/SDL.h>
void sdl_pixel_doubler (Surface *src, SDL_Surface *dest);
