extern const struct {
	unsigned int width;
	unsigned int height;
	unsigned int bytes_per_pixel;
	unsigned int rle_size;
	unsigned char rle_pixel [49725];
} the_font ;
