#ifndef _TENTACLE3D_H
#define _TENTACLE3D_H

#include "goom_visual_fx.h"

VisualFX tentacle_fx_create(void);

#endif
